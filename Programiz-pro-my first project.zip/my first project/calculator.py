def add(x, y):
  """Adds two numbers."""
  return x + y

def subtract(x, y):
  """Subtracts two numbers."""
  return x - y

def multiply(x, y):
  """Multiplies two numbers."""
  return x * y

def divide(x, y):
  """Divides two numbers."""
  return x / y

def main():
  """Prompts the user for two numbers and performs the desired operation."""
  operation = input("Please select the operation you would like to perform: ")
  number_1 = int(input("Please enter the first number: "))
  number_2 = int(input("Please enter the second number: "))

  if operation == "+":
    print(number_1, "+", number_2, "=", add(number_1, number_2))
  elif operation == "-":
    print(number_1, "-", number_2, "=", subtract(number_1, number_2))
  elif operation == "*":
    print(number_1, "*", number_2, "=", multiply(number_1, number_2))
  elif operation == "/":
    print(number_1, "/", number_2, "=", divide(number_1, number_2))
  else:
    print("Invalid operation.")

if __name__ == "__main__":
  main()